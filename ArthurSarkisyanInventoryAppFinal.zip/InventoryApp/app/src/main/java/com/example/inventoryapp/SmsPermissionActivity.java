package com.example.inventoryapp;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.telephony.PhoneNumberUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SmsPermissionActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 100;
    public static final String PREFS_NAME = "sms_settings";
    public static final String KEY_PHONE_NUMBER = "phone_number";

    private EditText phoneNumberInput;
    private SharedPreferences smsPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_sms_permission);

        ViewCompat.setOnApplyWindowInsetsListener(
                findViewById(R.id.main), (v, insets) -> {
                    Insets systemBars = insets.getInsets(
                            WindowInsetsCompat.Type.systemBars());

                    v.setPadding(
                            systemBars.left,
                            systemBars.top,
                            systemBars.right,
                            systemBars.bottom
                    );

                    return insets;
                });

        smsPreferences = getSharedPreferences(
                PREFS_NAME, MODE_PRIVATE);

        phoneNumberInput =
                findViewById(R.id.editTextPhoneNumber);

        Button enableSmsButton =
                findViewById(R.id.buttonEnableSms);

        Button notNowButton =
                findViewById(R.id.buttonNotNow);

        String savedNumber = smsPreferences.getString(
                KEY_PHONE_NUMBER, "");

        phoneNumberInput.setText(savedNumber);

        enableSmsButton.setOnClickListener(v ->
                saveNumberAndCheckPermission());

        notNowButton.setOnClickListener(v -> finish());
    }

    // Validate and persist the recipient before requesting SMS permission.
    private void saveNumberAndCheckPermission() {

        String phoneNumber = phoneNumberInput.getText()
                .toString().trim();

        if (phoneNumber.isEmpty()) {
            phoneNumberInput.setError(
                    "Please enter a phone number.");
            phoneNumberInput.requestFocus();
            return;
        }

        String normalizedNumber =
                PhoneNumberUtils.normalizeNumber(phoneNumber);

        if (!normalizedNumber.matches("\\+?[0-9]{10,15}")) {
            phoneNumberInput.setError(
                    "Enter a valid phone number with 10 to 15 digits.");
            phoneNumberInput.requestFocus();
            return;
        }

        smsPreferences.edit()
                .putString(KEY_PHONE_NUMBER, normalizedNumber)
                .apply();

        Toast.makeText(
                this,
                "SMS phone number saved.",
                Toast.LENGTH_SHORT
        ).show();

        checkSmsPermission();
    }

    // Respect prior permission decisions and direct users to Settings when needed.
    private void checkSmsPermission() {

        if (ContextCompat.checkSelfPermission(
                this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {

            Toast.makeText(
                    this,
                    "SMS notifications are already enabled.",
                    Toast.LENGTH_SHORT
            ).show();

        } else if (getPreferences(MODE_PRIVATE)
                .getBoolean("sms_permission_requested", false)
                && !ActivityCompat.shouldShowRequestPermissionRationale(
                this, Manifest.permission.SEND_SMS)) {

            Toast.makeText(
                    this,
                    "Enable SMS permission in Android Settings.",
                    Toast.LENGTH_LONG
            ).show();

            Intent intent = new Intent(
                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + getPackageName())
            );

            startActivity(intent);

        } else {

            getPreferences(MODE_PRIVATE)
                    .edit()
                    .putBoolean("sms_permission_requested", true)
                    .apply();

            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE
            );
        }
    }

    // A denied permission disables alerts but never blocks inventory management.
    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            String[] permissions,
            int[] grantResults) {

        super.onRequestPermissionsResult(
                requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {

            if (grantResults.length > 0
                    && grantResults[0]
                    == PackageManager.PERMISSION_GRANTED) {

                Toast.makeText(
                        this,
                        "SMS notifications enabled.",
                        Toast.LENGTH_SHORT
                ).show();

            } else {

                Toast.makeText(
                        this,
                        "SMS permission denied. The app will continue without SMS notifications.",
                        Toast.LENGTH_LONG
                ).show();
            }
        }
    }
}
