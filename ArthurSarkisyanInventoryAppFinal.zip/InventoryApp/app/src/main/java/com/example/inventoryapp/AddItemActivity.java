package com.example.inventoryapp;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class AddItemActivity extends AppCompatActivity {

    private static final String TAG = "AddItemActivity";

    private EditText editTextItemName;
    private EditText editTextQuantity;
    private Button saveItemButton;

    private DatabaseHelper databaseHelper;

    private final ExecutorService databaseExecutor =
            Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_item);

        ViewCompat.setOnApplyWindowInsetsListener(
                findViewById(R.id.main), (v, insets) -> {

                    Insets systemBars = insets.getInsets(
                            WindowInsetsCompat.Type.systemBars());

                    v.setPadding(
                            systemBars.left,
                            systemBars.top,
                            systemBars.right,
                            systemBars.bottom
                    );

                    return insets;
                });

        databaseHelper = new DatabaseHelper(this);

        editTextItemName = findViewById(R.id.editTextItemName);
        editTextQuantity = findViewById(R.id.editTextQuantity);

        saveItemButton = findViewById(R.id.buttonSaveItem);
        Button cancelButton = findViewById(R.id.buttonCancel);

        // Save the entered inventory item.
        saveItemButton.setOnClickListener(v -> saveInventoryItem());

        // Return without saving.
        cancelButton.setOnClickListener(v -> finish());
    }

    private void saveInventoryItem() {

        String itemName = editTextItemName.getText()
                .toString().trim();

        String quantityInput = editTextQuantity.getText()
                .toString().trim();

        // Require an item name.
        if (itemName.isEmpty()) {
            editTextItemName.setError("Enter an item name.");
            editTextItemName.requestFocus();
            return;
        }

        // Require a quantity.
        if (quantityInput.isEmpty()) {
            editTextQuantity.setError("Enter a quantity.");
            editTextQuantity.requestFocus();
            return;
        }

        int quantity;

        try {
            quantity = Integer.parseInt(quantityInput);
        } catch (NumberFormatException e) {
            editTextQuantity.setError("Enter a valid quantity.");
            editTextQuantity.requestFocus();
            return;
        }

        // Prevent negative quantities.
        if (quantity < 0) {
            editTextQuantity.setError(
                    "Quantity cannot be negative.");
            editTextQuantity.requestFocus();
            return;
        }

        // Prevent duplicate taps while saving.
        saveItemButton.setEnabled(false);

        databaseExecutor.execute(() -> {

            boolean saved = false;

            try {
                saved = databaseHelper.addInventoryItem(
                        itemName, quantity);
            } catch (Exception e) {
                Log.e(TAG, "Failed to save inventory item", e);
            }

            final boolean saveSuccessful = saved;

            runOnUiThread(() -> {

                if (saveSuccessful) {

                    Toast.makeText(
                            AddItemActivity.this,
                            "Item saved successfully!",
                            Toast.LENGTH_SHORT
                    ).show();

                    // Return to the Inventory screen.
                    finish();

                } else {

                    saveItemButton.setEnabled(true);

                    Toast.makeText(
                            AddItemActivity.this,
                            "Unable to save item. Please try again.",
                            Toast.LENGTH_SHORT
                    ).show();
                }
            });
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        databaseExecutor.shutdown();
        databaseHelper.close();
    }
}
