
package com.example.inventoryapp;

import android.content.Context;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Base64;
import android.util.Log;

import java.security.MessageDigest;
import java.security.SecureRandom;
import java.security.spec.KeySpec;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "InventoryApp.db";
    private static final int DATABASE_VERSION = 1;
    private static final String TAG = "DatabaseHelper";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // Create the users table for account information.
        db.execSQL("CREATE TABLE users (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT NOT NULL UNIQUE, " +
                "password_hash TEXT NOT NULL, " +
                "password_salt TEXT NOT NULL)");

        // Create the inventory table for stored items.
        db.execSQL("CREATE TABLE inventory (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "item_name TEXT NOT NULL, " +
                "quantity INTEGER NOT NULL DEFAULT 0 " +
                "CHECK(quantity >= 0))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db,
                          int oldVersion, int newVersion) {

        // Future database migrations will be handled here.
    }

    // Register a new user in the SQLite database.
    public boolean registerUser(String username, String password) {

        // Check that the username and password are not empty.
        if (username == null || username.trim().isEmpty()
                || password == null || password.isEmpty()) {
            return false;
        }

        try {
            // Generate a random salt for password security.
            byte[] salt = new byte[16];
            new SecureRandom().nextBytes(salt);

            // Convert the salt into a string for storage.
            String encodedSalt = Base64.encodeToString(
                    salt, Base64.NO_WRAP);

            // Hash the password before saving it.
            String passwordHash = hashPassword(password, salt);

            // Prepare user information for the database.
            ContentValues values = new ContentValues();
            values.put("username", username.trim());
            values.put("password_hash", passwordHash);
            values.put("password_salt", encodedSalt);

            // Insert the new account into the users table.
            long result = getWritableDatabase().insert(
                    "users", null, values);

            return result != -1;

        } catch (Exception e) {
            Log.e(TAG, "Account registration failed", e);
            return false;
        }
    }

    // Hash passwords using PBKDF2 with SHA-256.
    private String hashPassword(String password, byte[] salt)
            throws Exception {

        KeySpec spec = new PBEKeySpec(
                password.toCharArray(),
                salt,
                120000,
                256
        );

        SecretKeyFactory factory =
                SecretKeyFactory.getInstance(
                        "PBKDF2WithHmacSHA256");

        byte[] hash = factory.generateSecret(spec)
                .getEncoded();

        // Convert the hashed password into a string.
        return Base64.encodeToString(hash, Base64.NO_WRAP);
    }

    // Verify login credentials against the users table.
    public boolean loginUser(String username, String password) {

        if (username == null || password == null) {
            return false;
        }

        String query = "SELECT password_hash, password_salt " +
                "FROM users WHERE username = ?";

        try (Cursor cursor = getReadableDatabase().rawQuery(
                query, new String[]{username.trim()})) {

            if (cursor.moveToFirst()) {

                String storedHash = cursor.getString(0);
                String storedSalt = cursor.getString(1);

                // Decode the salt saved during registration.
                byte[] salt = Base64.decode(
                        storedSalt, Base64.NO_WRAP);

                // Hash the entered password using the same salt.
                String enteredHash = hashPassword(password, salt);

                // Compare password hashes securely.
                return MessageDigest.isEqual(
                        Base64.decode(storedHash, Base64.NO_WRAP),
                        Base64.decode(enteredHash, Base64.NO_WRAP)
                );
            }

        } catch (Exception e) {
            Log.e(TAG, "Login verification failed", e);
        }

        return false;
    }

    // Add a new item to the inventory database.
    public boolean addInventoryItem(String itemName, int quantity) {

        if (itemName == null || itemName.trim().isEmpty()
                || quantity < 0) {
            return false;
        }

        ContentValues values = new ContentValues();
        values.put("item_name", itemName.trim());
        values.put("quantity", quantity);

        long result = getWritableDatabase().insert(
                "inventory", null, values);

        return result != -1;
    }

    // Retrieve all inventory items in alphabetical order.
    // The calling activity must close the returned Cursor.
    public Cursor getAllInventoryItems() {

        return getReadableDatabase().query(
                "inventory",
                new String[]{"id", "item_name", "quantity"},
                null,
                null,
                null,
                null,
                "item_name ASC"
        );
    }

    // Update the quantity of an existing inventory item.
    public boolean updateInventoryQuantity(long itemId, int quantity) {

        if (quantity < 0) {
            return false;
        }

        ContentValues values = new ContentValues();
        values.put("quantity", quantity);

        int rowsUpdated = getWritableDatabase().update(
                "inventory",
                values,
                "id = ?",
                new String[]{String.valueOf(itemId)}
        );

        return rowsUpdated > 0;
    }

    // Delete an inventory item using its unique ID.
    public boolean deleteInventoryItem(long itemId) {

        int rowsDeleted = getWritableDatabase().delete(
                "inventory",
                "id = ?",
                new String[]{String.valueOf(itemId)}
        );

        return rowsDeleted > 0;
    }
}
