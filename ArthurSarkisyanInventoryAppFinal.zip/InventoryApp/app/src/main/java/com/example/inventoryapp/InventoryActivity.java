package com.example.inventoryapp;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class InventoryActivity extends AppCompatActivity {

    private static final String TAG = "InventoryActivity";

    private DatabaseHelper databaseHelper;
    private TableLayout tableInventory;

    private final ExecutorService databaseExecutor =
            Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_inventory);

        ViewCompat.setOnApplyWindowInsetsListener(
                findViewById(R.id.main), (v, insets) -> {

                    Insets systemBars = insets.getInsets(
                            WindowInsetsCompat.Type.systemBars());

                    v.setPadding(
                            systemBars.left,
                            systemBars.top,
                            systemBars.right,
                            systemBars.bottom
                    );

                    return insets;
                });

        databaseHelper = new DatabaseHelper(this);
        tableInventory = findViewById(R.id.tableInventory);

        Button addItemButton =
                findViewById(R.id.buttonAddItem);

        Button smsNotificationsButton =
                findViewById(R.id.buttonSmsNotifications);

        addItemButton.setOnClickListener(v -> {
            Intent intent = new Intent(
                    InventoryActivity.this,
                    AddItemActivity.class
            );
            startActivity(intent);
        });

        smsNotificationsButton.setOnClickListener(v -> {
            Intent intent = new Intent(
                    InventoryActivity.this,
                    SmsPermissionActivity.class
            );
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadInventoryItems();
    }

    private void loadInventoryItems() {

        databaseExecutor.execute(() -> {

            List<InventoryItem> items = new ArrayList<>();

            try (Cursor cursor =
                         databaseHelper.getAllInventoryItems()) {

                int idColumn =
                        cursor.getColumnIndexOrThrow("id");

                int nameColumn =
                        cursor.getColumnIndexOrThrow("item_name");

                int quantityColumn =
                        cursor.getColumnIndexOrThrow("quantity");

                while (cursor.moveToNext()) {

                    long id = cursor.getLong(idColumn);
                    String name = cursor.getString(nameColumn);
                    int quantity = cursor.getInt(quantityColumn);

                    items.add(new InventoryItem(
                            id, name, quantity));
                }

                runOnUiThread(() ->
                        displayInventoryItems(items));

            } catch (Exception e) {

                Log.e(TAG, "Failed to load inventory", e);

                runOnUiThread(() ->
                        Toast.makeText(
                                this,
                                "Unable to load inventory.",
                                Toast.LENGTH_SHORT
                        ).show());
            }
        });
    }

    private void displayInventoryItems(List<InventoryItem> items) {

        tableInventory.removeViews(
                1,
                Math.max(0,
                        tableInventory.getChildCount() - 1)
        );

        if (items.isEmpty()) {

            TextView emptyMessage = new TextView(this);

            emptyMessage.setText(
                    "No inventory items yet. Tap Add Item to begin.");

            emptyMessage.setPadding(8, 24, 8, 24);

            tableInventory.addView(emptyMessage);
            return;
        }

        for (InventoryItem item : items) {

            TableRow row = new TableRow(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(0, 0, 0, dpToPx(8));

            TextView nameText = new TextView(this);
            nameText.setText(item.name);

            row.addView(nameText,
                    new TableRow.LayoutParams(
                            0,
                            TableRow.LayoutParams.WRAP_CONTENT,
                            1f
                    ));

            TextView quantityText = new TextView(this);

            quantityText.setText(
                    String.valueOf(item.quantity));

            quantityText.setGravity(Gravity.CENTER);

            row.addView(quantityText,
                    new TableRow.LayoutParams(
                            0,
                            TableRow.LayoutParams.WRAP_CONTENT,
                            1f
                    ));

            LinearLayout actions = new LinearLayout(this);
            actions.setOrientation(LinearLayout.HORIZONTAL);
            actions.setGravity(Gravity.CENTER);

            Button decreaseButton =
                    createActionButton("-", 48, 14);

            Button increaseButton =
                    createActionButton("+", 48, 14);

            Button deleteButton =
                    createActionButton("Delete", 72, 12);

            decreaseButton.setContentDescription(
                    "Decrease " + item.name + " quantity");

            increaseButton.setContentDescription(
                    "Increase " + item.name + " quantity");

            deleteButton.setContentDescription(
                    "Delete " + item.name);

            // Prevent negative stock counts when the user taps the decrease button.
            decreaseButton.setOnClickListener(v -> {

                if (item.quantity > 0) {

                    updateQuantity(
                            item.id,
                            item.name,
                            item.quantity,
                            item.quantity - 1
                    );

                } else {

                    Toast.makeText(
                            this,
                            "Quantity cannot go below zero.",
                            Toast.LENGTH_SHORT
                    ).show();
                }
            });

            // Guard against integer overflow before increasing the stored quantity.
            increaseButton.setOnClickListener(v -> {

                if (item.quantity < Integer.MAX_VALUE) {

                    updateQuantity(
                            item.id,
                            item.name,
                            item.quantity,
                            item.quantity + 1
                    );

                } else {

                    Toast.makeText(
                            this,
                            "Maximum quantity reached.",
                            Toast.LENGTH_SHORT
                    ).show();
                }
            });

            deleteButton.setOnClickListener(v ->
                    deleteInventoryItem(item.id));

            actions.addView(decreaseButton);
            actions.addView(increaseButton);
            actions.addView(deleteButton);

            row.addView(actions,
                    new TableRow.LayoutParams(
                            dpToPx(168),
                            TableRow.LayoutParams.WRAP_CONTENT
                    ));

            tableInventory.addView(row);
        }
    }

    private Button createActionButton(
            String text, int widthDp, int textSizeSp) {

        Button button = new Button(this);

        button.setText(text);
        button.setTextSize(textSizeSp);
        button.setAllCaps(false);
        button.setMinWidth(0);
        button.setMinimumWidth(0);
        button.setPadding(0, 0, 0, 0);

        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(
                        dpToPx(widthDp),
                        dpToPx(48)
                );

        button.setLayoutParams(params);

        return button;
    }

    // Update SQLite off the UI thread, then refresh the grid after success.
    private void updateQuantity(
            long itemId,
            String itemName,
            int oldQuantity,
            int newQuantity) {

        databaseExecutor.execute(() -> {

            try {

                boolean updated =
                        databaseHelper.updateInventoryQuantity(
                                itemId, newQuantity);

                runOnUiThread(() -> {

                    if (updated) {

                        loadInventoryItems();

                        // Alert only when an existing positive stock count reaches zero.
                        if (oldQuantity > 0 && newQuantity == 0) {
                            sendLowInventorySms(itemName);
                        }

                    } else {

                        Toast.makeText(
                                this,
                                "Unable to update quantity.",
                                Toast.LENGTH_SHORT
                        ).show();
                    }
                });

            } catch (Exception e) {

                Log.e(TAG, "Failed to update quantity", e);

                runOnUiThread(() ->
                        Toast.makeText(
                                this,
                                "Unable to update quantity.",
                                Toast.LENGTH_SHORT
                        ).show());
            }
        });
    }

    // SMS alerts are optional: skip sending if no recipient or permission exists.
    private void sendLowInventorySms(String itemName) {

        SharedPreferences smsPreferences =
                getSharedPreferences(
                        SmsPermissionActivity.PREFS_NAME,
                        MODE_PRIVATE
                );

        String phoneNumber = smsPreferences.getString(
                SmsPermissionActivity.KEY_PHONE_NUMBER,
                ""
        );

        if (phoneNumber == null || phoneNumber.isEmpty()) {

            Toast.makeText(
                    this,
                    "Low stock! Set up an SMS phone number to receive alerts.",
                    Toast.LENGTH_LONG
            ).show();

            return;
        }

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {

            Toast.makeText(
                    this,
                    "Low stock! SMS permission is not enabled.",
                    Toast.LENGTH_LONG
            ).show();

            return;
        }

        String message =
                "Inventory Alert: " + itemName
                        + " is out of stock. Quantity: 0.";

        try {

            SmsManager smsManager =
                    getSystemService(SmsManager.class);

            if (smsManager == null) {
                throw new IllegalStateException(
                        "SMS service unavailable.");
            }

            smsManager.sendTextMessage(
                    phoneNumber,
                    null,
                    message,
                    null,
                    null
            );

            Toast.makeText(
                    this,
                    "Low-stock SMS submitted for sending.",
                    Toast.LENGTH_SHORT
            ).show();

        } catch (Exception e) {

            Log.e(TAG, "Failed to send low-stock SMS", e);

            Toast.makeText(
                    this,
                    "Unable to send low-stock SMS.",
                    Toast.LENGTH_LONG
            ).show();
        }
    }

    private void deleteInventoryItem(long itemId) {

        databaseExecutor.execute(() -> {

            try {

                boolean deleted =
                        databaseHelper.deleteInventoryItem(itemId);

                runOnUiThread(() -> {

                    if (deleted) {

                        loadInventoryItems();

                    } else {

                        Toast.makeText(
                                this,
                                "Unable to delete item.",
                                Toast.LENGTH_SHORT
                        ).show();
                    }
                });

            } catch (Exception e) {

                Log.e(TAG, "Failed to delete item", e);

                runOnUiThread(() ->
                        Toast.makeText(
                                this,
                                "Unable to delete item.",
                                Toast.LENGTH_SHORT
                        ).show());
            }
        });
    }

    private int dpToPx(int dp) {

        return Math.round(
                dp * getResources()
                        .getDisplayMetrics().density
        );
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        databaseExecutor.shutdown();
        databaseHelper.close();
    }

    private static class InventoryItem {

        final long id;
        final String name;
        final int quantity;

        InventoryItem(long id, String name, int quantity) {
            this.id = id;
            this.name = name;
            this.quantity = quantity;
        }
    }
}
