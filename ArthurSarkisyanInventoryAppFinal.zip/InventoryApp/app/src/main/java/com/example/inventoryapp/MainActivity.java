
package com.example.inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private EditText editTextUsername;
    private EditText editTextPassword;
    private Button loginButton;
    private Button createAccountButton;

    private DatabaseHelper databaseHelper;
    private final ExecutorService executor =
            Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        // Apply system bar spacing.
        ViewCompat.setOnApplyWindowInsetsListener(
                findViewById(R.id.main), (v, insets) -> {

                    Insets systemBars = insets.getInsets(
                            WindowInsetsCompat.Type.systemBars());

                    v.setPadding(
                            systemBars.left,
                            systemBars.top,
                            systemBars.right,
                            systemBars.bottom
                    );

                    return insets;
                });

        // Initialize database access.
        databaseHelper = new DatabaseHelper(this);

        // Connect Java components to the login layout.
        editTextUsername =
                findViewById(R.id.editTextUsername);

        editTextPassword =
                findViewById(R.id.editTextPassword);

        loginButton =
                findViewById(R.id.buttonLogin);

        createAccountButton =
                findViewById(R.id.buttonCreateAccount);

        loginButton.setOnClickListener(v -> loginUser());

        createAccountButton.setOnClickListener(
                v -> createAccount());
    }

    // Enable or disable buttons while processing.
    private void setButtonsEnabled(boolean enabled) {
        loginButton.setEnabled(enabled);
        createAccountButton.setEnabled(enabled);
    }

    // Check login credentials in a background thread.
    private void loginUser() {

        String username = editTextUsername.getText()
                .toString().trim();

        String password = editTextPassword.getText()
                .toString();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this,
                    "Please enter your username and password.",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        setButtonsEnabled(false);

        executor.execute(() -> {

            boolean isValid =
                    databaseHelper.loginUser(username, password);

            runOnUiThread(() -> {

                if (isFinishing() || isDestroyed()) {
                    return;
                }

                setButtonsEnabled(true);

                if (isValid) {
                    Toast.makeText(this,
                            "Login successful!",
                            Toast.LENGTH_SHORT).show();

                    openInventory();

                } else {
                    Toast.makeText(this,
                            "Invalid username or password.",
                            Toast.LENGTH_SHORT).show();
                }
            });
        });
    }

    // Register a new account in a background thread.
    private void createAccount() {

        String username = editTextUsername.getText()
                .toString().trim();

        String password = editTextPassword.getText()
                .toString();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this,
                    "Please enter a username and password.",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        if (password.length() < 8) {
            Toast.makeText(this,
                    "Password must be at least 8 characters.",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        setButtonsEnabled(false);

        executor.execute(() -> {

            boolean isCreated =
                    databaseHelper.registerUser(username, password);

            runOnUiThread(() -> {

                if (isFinishing() || isDestroyed()) {
                    return;
                }

                setButtonsEnabled(true);

                if (isCreated) {
                    Toast.makeText(this,
                            "Account created successfully!",
                            Toast.LENGTH_SHORT).show();

                    openInventory();

                } else {
                    Toast.makeText(this,
                            "Unable to create account. " +
                                    "Username may already exist.",
                            Toast.LENGTH_LONG).show();
                }
            });
        });
    }

    // Navigate to the inventory screen.
    private void openInventory() {

        Intent intent = new Intent(
                MainActivity.this,
                InventoryActivity.class
        );

        startActivity(intent);
        finish();
    }

    @Override
    protected void onDestroy() {
        executor.shutdown();
        super.onDestroy();
    }
}
